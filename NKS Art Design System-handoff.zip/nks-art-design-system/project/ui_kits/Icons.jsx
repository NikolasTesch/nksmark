/* NKS Art — icon set (Lucide path data, stroke 1.75)
   Inline SVG so icons survive React re-renders. */
(function () {
  const S = ({ size = 18, sw = 1.75, children, style }) =>
    React.createElement('svg', {
      xmlns: 'http://www.w3.org/2000/svg', width: size, height: size,
      viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
      strokeWidth: sw, strokeLinecap: 'round', strokeLinejoin: 'round',
      style,
    }, children);
  const P = (d) => React.createElement('path', { d, key: d });

  const Icon = {
    Search: (p) => S({ ...p, children: [P('m21 21-4.34-4.34'), React.createElement('circle', { cx: 11, cy: 11, r: 8, key: 'c' })] }),
    Download: (p) => S({ ...p, children: [P('M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'), P('M7 10l5 5 5-5'), P('M12 15V3')] }),
    Lock: (p) => S({ ...p, children: [React.createElement('rect', { width: 18, height: 11, x: 3, y: 11, rx: 2, ry: 2, key: 'r' }), P('M7 11V7a5 5 0 0 1 10 0v4')] }),
    Image: (p) => S({ ...p, children: [React.createElement('rect', { width: 18, height: 18, x: 3, y: 3, rx: 2, key: 'r' }), React.createElement('circle', { cx: 9, cy: 9, r: 2, key: 'c' }), P('m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21')] }),
    Heart: (p) => S({ ...p, children: [P('M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.5 4.04 3 5.5l7 7Z')] }),
    User: (p) => S({ ...p, children: [P('M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2'), React.createElement('circle', { cx: 12, cy: 7, r: 4, key: 'c' })] }),
    ChevronRight: (p) => S({ ...p, children: [P('m9 18 6-6-6-6')] }),
    ChevronDown: (p) => S({ ...p, children: [P('m6 9 6 6 6-6')] }),
    X: (p) => S({ ...p, children: [P('M18 6 6 18'), P('m6 6 12 12')] }),
    Check: (p) => S({ ...p, children: [P('M20 6 9 17l-5-5')] }),
    Plus: (p) => S({ ...p, children: [P('M5 12h14'), P('M12 5v14')] }),
    Menu: (p) => S({ ...p, children: [P('M4 12h16'), P('M4 6h16'), P('M4 18h16')] }),
    Upload: (p) => S({ ...p, children: [P('M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'), P('M17 8l-5-5-5 5'), P('M12 3v12')] }),
    Pencil: (p) => S({ ...p, children: [P('M21.17 6.83 17.17 2.83a2.83 2.83 0 0 0-4 0L3 13v4h4L21.17 6.83z'), P('m15 5 4 4')] }),
    Trash: (p) => S({ ...p, children: [P('M3 6h18'), P('M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2')] }),
    Tag: (p) => S({ ...p, children: [P('M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z'), React.createElement('circle', { cx: 7.5, cy: 7.5, r: 0.5, fill: 'currentColor', key: 'c' })] }),
    Folder: (p) => S({ ...p, children: [P('M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z')] }),
    SlidersHorizontal: (p) => S({ ...p, children: [P('M10 5H3'), P('M21 5h-6'), P('M14 5a2 2 0 1 0 4 0 2 2 0 1 0-4 0'), P('M21 12H10'), P('M3 12h3'), P('M6 12a2 2 0 1 0 4 0 2 2 0 1 0-4 0'), P('M10 19H3'), P('M21 19h-6'), P('M14 19a2 2 0 1 0 4 0 2 2 0 1 0-4 0')] }),
    LayoutGrid: (p) => S({ ...p, children: [React.createElement('rect', { width: 7, height: 7, x: 3, y: 3, rx: 1, key: 'a' }), React.createElement('rect', { width: 7, height: 7, x: 14, y: 3, rx: 1, key: 'b' }), React.createElement('rect', { width: 7, height: 7, x: 14, y: 14, rx: 1, key: 'c' }), React.createElement('rect', { width: 7, height: 7, x: 3, y: 14, rx: 1, key: 'd' })] }),
    Users: (p) => S({ ...p, children: [P('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2'), React.createElement('circle', { cx: 9, cy: 7, r: 4, key: 'c' }), P('M22 21v-2a4 4 0 0 0-3-3.87'), P('M16 3.13a4 4 0 0 1 0 7.75')] }),
    History: (p) => S({ ...p, children: [P('M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8'), P('M3 3v5h5'), P('M12 7v5l4 2')] }),
    GripVertical: (p) => S({ ...p, children: [React.createElement('circle', { cx: 9, cy: 5, r: 1, fill: 'currentColor', key: 'a' }), React.createElement('circle', { cx: 9, cy: 12, r: 1, fill: 'currentColor', key: 'b' }), React.createElement('circle', { cx: 9, cy: 19, r: 1, fill: 'currentColor', key: 'c' }), React.createElement('circle', { cx: 15, cy: 5, r: 1, fill: 'currentColor', key: 'd' }), React.createElement('circle', { cx: 15, cy: 12, r: 1, fill: 'currentColor', key: 'e' }), React.createElement('circle', { cx: 15, cy: 19, r: 1, fill: 'currentColor', key: 'f' })] }),
    LogOut: (p) => S({ ...p, children: [P('M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'), P('m16 17 5-5-5-5'), P('M21 12H9')] }),
  };
  window.Icon = Icon;
})();
