/* NKS Art — mock data for the Loja kit */
(function () {
  window.CATEGORIES = [
    { slug: 'sublimacao', name: 'Sublimação' },
    { slug: 'frases', name: 'Frases' },
    { slug: 'floral', name: 'Floral' },
    { slug: 'datas', name: 'Datas comemorativas' },
    { slug: 'infantil', name: 'Infantil' },
    { slug: 'religioso', name: 'Religioso' },
  ];

  // tint = subtle neutral wash behind the preview placeholder
  window.ARTWORKS = [
    { id: 1, title: 'Mandala floral aquarela', cat: 'floral', tags: ['floral', 'aquarela'], formats: ['CDR', 'AI', 'PDF'], free: false, downloads: 320, added: '12 mai', tint: '#F4F1EE' },
    { id: 2, title: 'Lettering “Feliz Dia das Mães”', cat: 'frases', tags: ['lettering', 'datas'], formats: ['PDF', 'AI'], free: true, downloads: 1180, added: '02 mai', tint: '#F2F3F5' },
    { id: 3, title: 'Buquê de rosas vetorial', cat: 'floral', tags: ['floral', 'rosas'], formats: ['CDR', 'AI'], free: false, downloads: 540, added: '28 abr', tint: '#F5F1F1' },
    { id: 4, title: 'Coroa de flores minimal', cat: 'floral', tags: ['floral', 'minimal'], formats: ['AI', 'PDF', 'OTF'], free: false, downloads: 210, added: '21 abr', tint: '#F1F3F2' },
    { id: 5, title: 'Frase “Café & Fé”', cat: 'frases', tags: ['lettering', 'fé'], formats: ['PDF'], free: true, downloads: 760, added: '18 abr', tint: '#F4F2EF' },
    { id: 6, title: 'Estampa Festa Junina', cat: 'datas', tags: ['festa', 'junina'], formats: ['CDR', 'PDF'], free: false, downloads: 430, added: '15 abr', tint: '#F5F2EE' },
    { id: 7, title: 'Ursinho aquarela bebê', cat: 'infantil', tags: ['bebê', 'aquarela'], formats: ['AI', 'PDF'], free: false, downloads: 380, added: '10 abr', tint: '#F2F3F5' },
    { id: 8, title: 'Cruz floral religiosa', cat: 'religioso', tags: ['fé', 'floral'], formats: ['CDR', 'AI', 'PDF'], free: false, downloads: 290, added: '06 abr', tint: '#F3F1F0' },
    { id: 9, title: 'Padrão tropical folhagem', cat: 'sublimacao', tags: ['tropical', 'padrão'], formats: ['CDR', 'AI'], free: false, downloads: 615, added: '01 abr', tint: '#F0F3F1' },
    { id: 10, title: 'Lettering “Bem-vindo Bebê”', cat: 'infantil', tags: ['bebê', 'lettering'], formats: ['PDF', 'OTF'], free: true, downloads: 905, added: '27 mar', tint: '#F4F2EF' },
    { id: 11, title: 'Coração doodle simples', cat: 'datas', tags: ['amor', 'doodle'], formats: ['AI', 'PDF'], free: true, downloads: 1320, added: '22 mar', tint: '#F5F1F1' },
    { id: 12, title: 'Selo “Feito à Mão”', cat: 'sublimacao', tags: ['selo', 'artesanal'], formats: ['CDR', 'AI', 'PDF', 'OTF'], free: false, downloads: 470, added: '18 mar', tint: '#F2F2F2' },
  ];
})();
