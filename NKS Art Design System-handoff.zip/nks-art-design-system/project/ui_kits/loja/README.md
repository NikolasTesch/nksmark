# UI Kit — Loja (catálogo público)

Recriação de alta fidelidade da loja pública do NKS Art. Catálogo navegável por qualquer
visitante; **comportamento muda conforme o role** — esse é o coração do produto.

## Como rodar
Abra `index.html`. Use o seletor **"Ver como" (Visitante / Fase / Admin)** no header para
alternar permissões em tempo real, ou clique em **Entrar** para o fluxo de login.

## O que demonstra
- **Visitante:** navega, filtra por categoria, busca por tag, abre o detalhe da arte — mas
  vê cadeado e "Faça login para baixar" no lugar do download.
- **Fase / Admin:** baixam livremente; o card e o modal trocam o link bloqueado por "Baixar".
- Filtro por categoria (chips), busca, favoritar (coração), badge "Grátis", estado vazio.

## Componentes (`*.jsx`)
| Arquivo | Componente |
|---|---|
| `Header.jsx` | Header preto editorial, nav institucional, seletor de role, login/conta |
| `ArtworkCard.jsx` | `ArtPreview` (placeholder neutro) + `ArtworkCard` — foco na imagem, categorias (não formatos), link sutil de download/bloqueio |
| `ArtworkModal.jsx` | Detalhe da arte — aqui sim aparecem os **formatos** (CDR/AI/PDF/OTF), tags, metadados e a ação por role |
| `app.jsx` | `Hero`, `FilterBar`, `LoginModal` e o `App` que liga tudo |
| `data.jsx` | Categorias + artes mock |

## Notas
- **Sem assets reais de arte:** os previews usam um placeholder neutro (ícone de imagem
  sobre `gray-100` com leve variação de tom). Substitua por imagens reais 4:3.
- Ícones via `../Icons.jsx` (Lucide). Estilos via `../../colors_and_type.css` + `../kit.css`.
- O card segue a direção aprovada pelo cliente: imagem dominante, sem botões pesados,
  categorias no lugar dos tipos de arquivo.
