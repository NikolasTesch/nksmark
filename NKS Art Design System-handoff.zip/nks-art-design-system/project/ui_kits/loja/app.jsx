/* NKS Art — Loja app: mini hero, left category rail, grid, login */
(function () {
  const { Icon } = window;
  const { useState, useMemo } = React;
  const SQ = "'Archivo', system-ui, sans-serif";

  function MiniHero() {
    return React.createElement('section', { style: hero.wrap },
      React.createElement('div', { style: hero.inner },
        React.createElement('div', null,
          React.createElement('span', { className: 'nks-eyebrow' }, 'Catálogo NKS Art'),
          React.createElement('h1', { className: 'nks-sq', style: hero.title }, 'Artes prontas para sublimação'),
          React.createElement('p', { style: hero.sub }, 'Estampas, frases e vetores prontos. Baixe em CDR, AI, PDF e OTF — liberado para a equipe.')
        ),
        React.createElement('div', { style: hero.stats },
          React.createElement('div', { style: hero.stat }, React.createElement('b', { className: 'nks-sq', style: hero.statN }, '1.240'), React.createElement('span', { style: hero.statL }, 'artes')),
          React.createElement('div', { style: hero.stat }, React.createElement('b', { className: 'nks-sq', style: hero.statN }, '6'), React.createElement('span', { style: hero.statL }, 'categorias'))
        )
      )
    );
  }

  function CategoryRail({ cats, counts, active, setActive, q, setQ }) {
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const Item = (slug, name, n) => {
      const on = active === slug;
      return React.createElement('button', {
        key: slug, onClick: () => setActive(slug),
        style: { ...rail.item, ...(on ? rail.itemOn : {}) },
      },
        React.createElement('span', { style: { ...rail.bar, background: on ? 'var(--nks-red)' : 'transparent' } }),
        React.createElement('span', { style: rail.itemName }, name),
        React.createElement('span', { style: { ...rail.itemCount, ...(on ? rail.itemCountOn : {}) } }, n)
      );
    };
    return React.createElement('aside', { style: rail.aside },
      React.createElement('div', { style: rail.searchWrap },
        React.createElement(Icon.Search, { size: 15, style: rail.searchIcon }),
        React.createElement('input', { className: 'input', style: rail.search, placeholder: 'Buscar arte ou tag…', value: q, onChange: e => setQ(e.target.value) })
      ),
      React.createElement('div', { className: 'nks-eyebrow', style: rail.heading }, 'Categorias'),
      React.createElement('nav', { style: rail.nav },
        Item('all', 'Tudo', total),
        cats.map(c => Item(c.slug, c.name, counts[c.slug] || 0))
      )
    );
  }

  function LoginModal({ open, onClose, onAuth }) {
    if (!open) return null;
    return React.createElement('div', { style: lg.overlay, onClick: onClose },
      React.createElement('div', { style: lg.modal, onClick: e => e.stopPropagation() },
        React.createElement('img', { src: '../../assets/nks-logo-mark.png', alt: 'NKS', style: lg.logo }),
        React.createElement('h2', { className: 'nks-sq', style: lg.title }, 'Entrar'),
        React.createElement('p', { style: lg.sub }, 'Acesso da equipe interna. Contas são criadas pelo admin.'),
        React.createElement('label', { className: 'field-label' }, 'E-mail'),
        React.createElement('input', { className: 'input', style: { marginBottom: 14 }, placeholder: 'voce@nksart.com.br', defaultValue: 'equipe@nksart.com.br' }),
        React.createElement('label', { className: 'field-label' }, 'Senha'),
        React.createElement('input', { className: 'input', type: 'password', style: { marginBottom: 20 }, defaultValue: '••••••••' }),
        React.createElement('button', { className: 'btn btn-primary btn-block', onClick: () => onAuth('fase') }, 'Entrar como Fase'),
        React.createElement('button', { className: 'btn btn-ghost btn-block', style: { marginTop: 10 }, onClick: () => onAuth('admin') }, 'Entrar como Admin'),
        React.createElement('button', { style: lg.cancel, onClick: onClose }, 'Cancelar')
      )
    );
  }

  function App() {
    const [role, setRole] = useState('visitante');
    const [active, setActive] = useState('all');
    const [q, setQ] = useState('');
    const [sel, setSel] = useState(null);
    const [login, setLogin] = useState(false);
    const [favs, setFavs] = useState({});
    const toggleFav = id => setFavs(f => ({ ...f, [id]: !f[id] }));

    const counts = useMemo(() => {
      const m = {};
      window.ARTWORKS.forEach(a => { m[a.cat] = (m[a.cat] || 0) + 1; });
      return m;
    }, []);

    const list = useMemo(() => window.ARTWORKS.filter(a => {
      if (active !== 'all' && a.cat !== active) return false;
      if (q) { const hay = (a.title + ' ' + a.tags.join(' ')).toLowerCase(); if (!hay.includes(q.toLowerCase())) return false; }
      return true;
    }), [active, q]);

    const activeName = active === 'all' ? 'Todas as artes' : (window.CATEGORIES.find(c => c.slug === active) || {}).name;

    return React.createElement(React.Fragment, null,
      React.createElement(window.Header, { role, setRole, onLogin: () => setLogin(true) }),
      React.createElement(MiniHero, null),
      React.createElement('div', { style: app.layout },
        React.createElement(CategoryRail, { cats: window.CATEGORIES, counts, active, setActive, q, setQ }),
        React.createElement('main', { style: app.content },
          React.createElement('div', { style: app.countRow },
            React.createElement('div', null,
              React.createElement('h2', { className: 'nks-sq', style: app.sectionTitle }, activeName),
              React.createElement('span', { style: app.count }, list.length + ' ' + (list.length === 1 ? 'arte' : 'artes'))
            ),
            role === 'visitante' && React.createElement('span', { style: app.hint },
              React.createElement(Icon.Lock, { size: 13 }), 'Faça login para baixar')
          ),
          list.length
            ? React.createElement('div', { style: app.grid },
                list.map(a => React.createElement(window.ArtworkCard, { key: a.id, art: a, role, onOpen: setSel, fav: !!favs[a.id], onFav: toggleFav })))
            : React.createElement('div', { style: app.empty }, 'Nenhuma arte nesta categoria ainda.')
        )
      ),
      React.createElement(window.ArtworkModal, { art: sel, role, onClose: () => setSel(null), onLogin: () => { setSel(null); setLogin(true); }, fav: sel ? !!favs[sel.id] : false, onFav: toggleFav }),
      React.createElement(LoginModal, { open: login, onClose: () => setLogin(false), onAuth: r => { setRole(r); setLogin(false); } })
    );
  }

  const hero = {
    wrap: { background: 'var(--nks-black)', color: '#fff' },
    inner: { maxWidth: 1180, margin: '0 auto', padding: '26px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 32, flexWrap: 'wrap' },
    title: { fontWeight: 800, fontSize: 28, lineHeight: 1.05, letterSpacing: '-.02em', textTransform: 'uppercase', margin: '7px 0 7px', color: '#fff', maxWidth: 560 },
    sub: { fontSize: 13.5, color: 'rgba(255,255,255,.62)', maxWidth: 480, margin: 0, lineHeight: 1.5 },
    stats: { display: 'flex', gap: 28 },
    stat: { display: 'flex', flexDirection: 'column' },
    statN: { fontWeight: 800, fontSize: 26, lineHeight: 1, color: 'var(--nks-red-light)' },
    statL: { fontSize: 11, textTransform: 'uppercase', letterSpacing: '.1em', color: 'rgba(255,255,255,.5)', marginTop: 4 },
  };
  const rail = {
    aside: { width: 230, flex: 'none', position: 'sticky', top: 88, alignSelf: 'flex-start' },
    searchWrap: { position: 'relative', marginBottom: 22 },
    searchIcon: { position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--nks-gray-400)' },
    search: { paddingLeft: 34, width: '100%' },
    heading: { display: 'block', marginBottom: 10, color: 'var(--nks-gray-400)' },
    nav: { display: 'flex', flexDirection: 'column', gap: 1 },
    item: { display: 'flex', alignItems: 'center', gap: 0, padding: '9px 12px 9px 0', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', borderRadius: 'var(--radius)', position: 'relative' },
    itemOn: {},
    bar: { width: 3, height: 18, borderRadius: 2, marginRight: 11, flex: 'none' },
    itemName: { flex: 1, fontSize: 14, fontWeight: 500, color: 'var(--nks-gray-700)' },
    itemCount: { fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--nks-gray-400)' },
    itemCountOn: { color: 'var(--nks-red)' },
  };
  const lg = {
    overlay: { position: 'fixed', inset: 0, background: 'rgba(17,17,17,.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 70 },
    modal: { width: 'min(380px,100%)', background: '#fff', borderRadius: 'var(--radius-lg)', padding: 32, boxShadow: 'var(--shadow-lg)' },
    logo: { height: 34, width: 'auto', display: 'block', marginBottom: 18 },
    title: { fontWeight: 800, fontSize: 24, textTransform: 'uppercase', letterSpacing: '-.01em', margin: '0 0 6px', color: 'var(--nks-black)' },
    sub: { fontSize: 13, color: 'var(--nks-gray-400)', margin: '0 0 22px' },
    cancel: { width: '100%', marginTop: 12, background: 'none', border: 'none', color: 'var(--nks-gray-400)', fontSize: 13, fontWeight: 500, cursor: 'pointer' },
  };
  const app = {
    layout: { maxWidth: 1180, margin: '0 auto', padding: '32px 28px 80px', display: 'flex', gap: 36, alignItems: 'flex-start' },
    content: { flex: 1, minWidth: 0 },
    countRow: { display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20 },
    sectionTitle: { fontWeight: 700, fontSize: 18, textTransform: 'uppercase', letterSpacing: '-.01em', color: 'var(--nks-black)', margin: '0 0 3px' },
    count: { fontSize: 12.5, color: 'var(--nks-gray-400)', fontWeight: 500 },
    hint: { display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--nks-red)', fontWeight: 500 },
    grid: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 18 },
    empty: { textAlign: 'center', padding: '80px 0', color: 'var(--nks-gray-400)', fontSize: 15 },
  };

  ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
})();
