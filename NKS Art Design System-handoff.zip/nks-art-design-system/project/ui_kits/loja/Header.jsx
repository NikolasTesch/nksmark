/* NKS Art — Loja header (black, editorial) + role switcher */
(function () {
  const { Icon } = window;

  function RoleSwitcher({ role, setRole }) {
    const roles = [
      { id: 'visitante', label: 'Visitante' },
      { id: 'fase', label: 'Fase' },
      { id: 'admin', label: 'Admin' },
    ];
    return React.createElement('div', { style: hs.roleWrap },
      React.createElement('span', { style: hs.roleHint }, 'Ver como'),
      React.createElement('div', { style: hs.roleSeg },
        roles.map(r =>
          React.createElement('button', {
            key: r.id, onClick: () => setRole(r.id),
            style: { ...hs.roleBtn, ...(role === r.id ? hs.roleBtnOn : {}) },
          }, r.label)
        )
      )
    );
  }

  function Header({ role, setRole, onLogin }) {
    const nav = ['Loja', 'FAQ', 'Suporte', 'Sugerir Arte', 'Quem Somos'];
    const authed = role === 'fase' || role === 'admin';
    return React.createElement('header', { style: hs.header },
      React.createElement('div', { style: hs.inner },
        React.createElement('div', { style: hs.left },
          React.createElement('img', { src: '../../assets/nks-logo-mark-white.png', alt: 'NKS Art', style: hs.logo }),
          React.createElement('nav', { style: hs.nav },
            nav.map((n, i) =>
              React.createElement('a', { key: n, href: '#', style: { ...hs.navLink, ...(i === 0 ? hs.navActive : {}) } }, n)
            )
          )
        ),
        React.createElement('div', { style: hs.right },
          React.createElement(RoleSwitcher, { role, setRole }),
          authed
            ? React.createElement('div', { style: hs.acct },
                role === 'admin'
                  ? React.createElement('span', { className: 'badge badge-cat', style: { letterSpacing: '.08em' } }, 'Admin')
                  : React.createElement('span', { className: 'badge badge-fase' }, 'Fase'),
                React.createElement('span', { style: hs.acctName }, 'Equipe NKS')
              )
            : React.createElement('button', { className: 'btn btn-primary btn-sm', onClick: onLogin },
                React.createElement(Icon.User, { size: 16 }), 'Entrar')
        )
      )
    );
  }

  const hs = {
    header: { background: 'var(--nks-black)', position: 'sticky', top: 0, zIndex: 40 },
    inner: { maxWidth: 1180, margin: '0 auto', padding: '0 28px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
    left: { display: 'flex', alignItems: 'center', gap: 36 },
    logo: { height: 30, width: 'auto', display: 'block' },
    nav: { display: 'flex', gap: 22 },
    navLink: { color: 'rgba(255,255,255,.66)', fontSize: 14, fontWeight: 500, textDecoration: 'none', paddingBottom: 2, borderBottom: '2px solid transparent' },
    navActive: { color: '#fff', borderBottomColor: 'var(--nks-red)' },
    right: { display: 'flex', alignItems: 'center', gap: 18 },
    roleWrap: { display: 'flex', alignItems: 'center', gap: 8 },
    roleHint: { color: 'rgba(255,255,255,.4)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '.1em' },
    roleSeg: { display: 'flex', background: 'rgba(255,255,255,.08)', borderRadius: 'var(--radius)', padding: 3, gap: 2 },
    roleBtn: { border: 'none', background: 'transparent', color: 'rgba(255,255,255,.6)', fontSize: 12, fontWeight: 500, padding: '5px 11px', borderRadius: 3 },
    roleBtnOn: { background: 'var(--nks-red)', color: '#fff' },
    acct: { display: 'flex', alignItems: 'center', gap: 9 },
    acctName: { color: '#fff', fontSize: 13, fontWeight: 500 },
  };

  window.Header = Header;
})();
