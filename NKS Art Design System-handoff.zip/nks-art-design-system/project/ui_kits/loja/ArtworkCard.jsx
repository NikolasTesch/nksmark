/* NKS Art — preview tile + artwork card (image-focused) */
(function () {
  const { Icon } = window;

  // Neutral placeholder preview (no real art assets available)
  function ArtPreview({ tint, big }) {
    return React.createElement('div', { style: { ...ac.prev, background: tint || 'var(--nks-gray-100)' } },
      React.createElement(Icon.Image, { size: big ? 56 : 46, style: { color: 'var(--nks-gray-400)', opacity: .6 } })
    );
  }

  function catLabel(art) {
    const catName = (window.CATEGORIES.find(c => c.slug === art.cat) || {}).name || art.cat;
    const extra = art.tags[0] && art.tags[0].toLowerCase() !== catName.toLowerCase() ? art.tags[0] : null;
    return { catName, extra };
  }

  function ArtworkCard({ art, role, onOpen, fav, onFav }) {
    const canDownload = role === 'fase' || role === 'admin';
    const { catName, extra } = catLabel(art);
    return React.createElement('div', {
      className: 'card', style: ac.card,
      onMouseEnter: e => { e.currentTarget.style.boxShadow = 'var(--shadow-md)'; const im = e.currentTarget.querySelector('.nks-prevImg'); if (im) im.style.transform = 'scale(1.05)'; },
      onMouseLeave: e => { e.currentTarget.style.boxShadow = 'none'; const im = e.currentTarget.querySelector('.nks-prevImg'); if (im) im.style.transform = 'scale(1)'; },
      onClick: () => onOpen(art),
    },
      React.createElement('div', { style: ac.prevWrap },
        React.createElement('div', { className: 'nks-prevImg', style: ac.prevImg },
          React.createElement(ArtPreview, { tint: art.tint })
        ),
        !canDownload && React.createElement('div', { style: ac.lock }, React.createElement(Icon.Lock, { size: 14 })),
        art.free && React.createElement('span', { className: 'badge badge-free', style: ac.freeBadge }, 'Grátis'),
        React.createElement('button', {
          style: { ...ac.fav, color: fav ? 'var(--nks-red)' : 'var(--nks-gray-400)' },
          onClick: e => { e.stopPropagation(); onFav && onFav(art.id); },
        }, React.createElement(Icon.Heart, { size: 16, style: fav ? { fill: 'var(--nks-red)' } : {} }))
      ),
      React.createElement('div', { style: ac.info },
        React.createElement('h3', { style: ac.title }, art.title),
        React.createElement('div', { style: ac.cats },
          React.createElement('span', { style: { color: 'var(--nks-red)' } }, catName),
          extra && (', ' + extra)
        )
      ),
      React.createElement('div', { style: ac.foot },
        canDownload
          ? React.createElement('button', { style: ac.lnk, onClick: e => { e.stopPropagation(); } },
              React.createElement(Icon.Download, { size: 15 }), 'Baixar arte')
          : React.createElement('button', { style: { ...ac.lnk, ...ac.lnkLocked }, onClick: e => { e.stopPropagation(); onOpen(art); } },
              React.createElement(Icon.Lock, { size: 14 }), 'Faça login para baixar')
      )
    );
  }

  const ac = {
    card: { cursor: 'pointer', transition: 'box-shadow var(--dur) var(--ease)', display: 'flex', flexDirection: 'column' },
    prevWrap: { position: 'relative', overflow: 'hidden' },
    prevImg: { transition: 'transform 320ms var(--ease)' },
    prev: { position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', aspectRatio: '4 / 5' },
    lock: { position: 'absolute', top: 9, left: 9, width: 26, height: 26, borderRadius: 'var(--radius-full)', background: 'rgba(0,0,0,.58)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    freeBadge: { position: 'absolute', bottom: 9, left: 9 },
    fav: { position: 'absolute', top: 9, right: 9, width: 28, height: 28, borderRadius: 'var(--radius-full)', background: 'rgba(255,255,255,.92)', boxShadow: 'var(--shadow-sm)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
    info: { padding: '9px 10px 8px', textAlign: 'center' },
    title: { margin: '0 0 3px', fontSize: 12.5, fontWeight: 600, color: 'var(--nks-black)', lineHeight: 1.25, minHeight: 31 },
    cats: { fontSize: 9, fontWeight: 500, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--nks-gray-400)' },
    foot: { borderTop: '1px solid var(--nks-gray-200)', padding: 8, textAlign: 'center' },
    lnk: { display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 600, color: 'var(--nks-red)', background: 'none', border: 'none', cursor: 'pointer' },
    lnkLocked: { color: 'var(--nks-gray-400)', fontWeight: 500 },
  };

  window.ArtPreview = ArtPreview;
  window.ArtworkCard = ArtworkCard;
})();
