/* NKS Art — artwork detail modal */
(function () {
  const { Icon } = window;

  function ArtworkModal({ art, role, onClose, onLogin, fav, onFav }) {
    if (!art) return null;
    const canDownload = role === 'fase' || role === 'admin';
    const catName = (window.CATEGORIES.find(c => c.slug === art.cat) || {}).name || art.cat;
    return React.createElement('div', { style: md.overlay, onClick: onClose },
      React.createElement('div', { style: md.modal, onClick: e => e.stopPropagation() },
        React.createElement('button', { style: md.close, onClick: onClose }, React.createElement(Icon.X, { size: 18 })),
        React.createElement('div', { style: md.grid },
          React.createElement('div', { style: { ...md.prev, background: art.tint } },
            React.createElement(window.ArtPreview, { tint: art.tint, big: true }),
            art.free && React.createElement('span', { className: 'badge badge-free', style: { position: 'absolute', top: 14, left: 14 } }, 'Grátis')
          ),
          React.createElement('div', { style: md.body },
            React.createElement('span', { className: 'nks-eyebrow' }, catName),
            React.createElement('h2', { style: md.title }, art.title),
            React.createElement('div', { style: md.tags },
              art.tags.map(t => React.createElement('span', { key: t, className: 'badge badge-tag' }, t))
            ),
            React.createElement('p', { style: md.meta }, 'Adicionada ' + art.added + ' · ' + art.downloads.toLocaleString('pt-BR') + ' downloads'),
            React.createElement('div', { style: md.fmtBlock },
              React.createElement('div', { style: md.fmtLabel }, 'Formatos disponíveis'),
              React.createElement('div', { style: md.fmts },
                art.formats.map(f => React.createElement('span', { key: f, className: 'fmt fmt-' + f, style: { fontSize: 12, padding: '4px 9px' } }, f))
              )
            ),
            canDownload
              ? React.createElement('div', { style: md.actions },
                  React.createElement('button', { className: 'btn btn-primary btn-block' },
                    React.createElement(Icon.Download, { size: 17 }), 'Baixar todos os arquivos'),
                  React.createElement('button', {
                    className: 'btn btn-ghost', onClick: () => onFav(art.id),
                    style: { color: fav ? 'var(--nks-red)' : 'var(--nks-gray-700)', borderColor: fav ? 'var(--nks-red)' : 'var(--nks-gray-200)' },
                  }, React.createElement(Icon.Heart, { size: 16, style: fav ? { fill: 'var(--nks-red)' } : {} }))
                )
              : React.createElement('div', { style: md.lockBox },
                  React.createElement('div', { style: md.lockRow },
                    React.createElement(Icon.Lock, { size: 16, style: { color: 'var(--nks-red)' } }),
                    React.createElement('span', { style: md.lockTxt }, 'Downloads liberados para a equipe interna.')
                  ),
                  React.createElement('button', { className: 'btn btn-primary btn-block', onClick: onLogin },
                    React.createElement(Icon.User, { size: 16 }), 'Faça login para baixar')
                )
          )
        )
      )
    );
  }

  const md = {
    overlay: { position: 'fixed', inset: 0, background: 'rgba(17,17,17,.55)', backdropFilter: 'blur(2px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 60 },
    modal: { position: 'relative', width: 'min(860px,100%)', background: '#fff', borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-lg)' },
    close: { position: 'absolute', top: 14, right: 14, width: 34, height: 34, borderRadius: 'var(--radius-full)', background: 'rgba(255,255,255,.9)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', zIndex: 2, color: 'var(--nks-black)' },
    grid: { display: 'grid', gridTemplateColumns: '1fr 1fr' },
    prev: { position: 'relative' },
    body: { padding: '34px 32px' },
    title: { fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, lineHeight: 1.08, letterSpacing: '-.02em', margin: '10px 0 14px', color: 'var(--nks-black)' },
    tags: { display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 14 },
    meta: { fontSize: 12, color: 'var(--nks-gray-400)', margin: '0 0 22px' },
    fmtBlock: { marginBottom: 24 },
    fmtLabel: { fontSize: 12, fontWeight: 500, color: 'var(--nks-gray-700)', marginBottom: 8 },
    fmts: { display: 'flex', flexWrap: 'wrap', gap: 7 },
    actions: { display: 'flex', gap: 10 },
    lockBox: { border: '1px solid var(--nks-red-subtle)', background: 'var(--nks-red-subtle)', borderRadius: 'var(--radius)', padding: 16 },
    lockRow: { display: 'flex', alignItems: 'center', gap: 9, marginBottom: 13 },
    lockTxt: { fontSize: 13, color: 'var(--nks-red-dark)', fontWeight: 500 },
  };

  window.ArtworkModal = ArtworkModal;
})();
