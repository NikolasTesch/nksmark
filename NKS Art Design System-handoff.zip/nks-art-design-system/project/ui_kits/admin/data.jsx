/* NKS Art — mock data for the Admin kit */
(function () {
  window.ADMIN_CATEGORIES = [
    { id: 1, name: 'Sublimação', slug: 'sublimacao', count: 412, color: '#B31217', filterOn: true },
    { id: 2, name: 'Frases', slug: 'frases', count: 286, color: '#111111', filterOn: true },
    { id: 3, name: 'Floral', slug: 'floral', count: 198, color: '#8B0D11', filterOn: true },
    { id: 4, name: 'Datas comemorativas', slug: 'datas', count: 144, color: '#3D3D3D', filterOn: true },
    { id: 5, name: 'Infantil', slug: 'infantil', count: 121, color: '#888888', filterOn: false },
    { id: 6, name: 'Religioso', slug: 'religioso', count: 79, color: '#B31217', filterOn: true },
    { id: 7, name: 'Rascunhos internos', slug: 'rascunhos', count: 0, color: '#DEDEDE', filterOn: false },
  ];

  window.ADMIN_TAGS = [
    { id: 1, name: 'floral', count: 198 }, { id: 2, name: 'lettering', count: 167 },
    { id: 3, name: 'aquarela', count: 142 }, { id: 4, name: 'minimal', count: 96 },
    { id: 5, name: 'datas', count: 88 }, { id: 6, name: 'bebê', count: 74 },
    { id: 7, name: 'fé', count: 61 }, { id: 8, name: 'tropical', count: 53 },
    { id: 9, name: 'doodle', count: 47 }, { id: 10, name: 'vintage', count: 33 },
    { id: 11, name: 'rosas', count: 29 }, { id: 12, name: 'selo', count: 12 },
  ];

  window.ADMIN_DOWNLOADS = [
    { user: 'Ana — Estamparia', email: 'ana@nksart.com.br', art: 'Mandala floral aquarela', fmt: 'CDR', when: 'há 12 min' },
    { user: 'Bruno — Produção', email: 'bruno@nksart.com.br', art: 'Lettering “Feliz Dia das Mães”', fmt: 'PDF', when: 'há 40 min' },
    { user: 'Ana — Estamparia', email: 'ana@nksart.com.br', art: 'Buquê de rosas vetorial', fmt: 'AI', when: 'há 1 h' },
    { user: 'Carla — Vendas', email: 'carla@nksart.com.br', art: 'Selo “Feito à Mão”', fmt: 'OTF', when: 'há 3 h' },
    { user: 'Bruno — Produção', email: 'bruno@nksart.com.br', art: 'Padrão tropical folhagem', fmt: 'CDR', when: 'ontem' },
    { user: 'Carla — Vendas', email: 'carla@nksart.com.br', art: 'Coração doodle simples', fmt: 'PDF', when: 'ontem' },
  ];

  window.ADMIN_USERS = [
    { name: 'Ana Beatriz', email: 'ana@nksart.com.br', role: 'fase', last: 'há 12 min', downloads: 482 },
    { name: 'Bruno Costa', email: 'bruno@nksart.com.br', role: 'fase', last: 'há 40 min', downloads: 311 },
    { name: 'Carla Dias', email: 'carla@nksart.com.br', role: 'fase', last: 'ontem', downloads: 207 },
  ];
})();
