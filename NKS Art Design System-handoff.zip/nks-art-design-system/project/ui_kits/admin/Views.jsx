/* NKS Art — Admin > Artes grid, Usuários Fase, Log de downloads */
(function () {
  const { Icon } = window;

  /* ---- Artes (gestão) ---- */
  function Artes() {
    const statusOf = i => (i % 7 === 6 ? 'Rascunho' : i % 5 === 4 ? 'Inativo' : 'Ativo');
    return React.createElement('div', null,
      React.createElement(window.Topbar, {
        title: 'Artes',
        desc: '1.240 artes no catálogo.',
        action: React.createElement('button', { className: 'btn btn-primary btn-sm' }, React.createElement(Icon.Plus, { size: 16 }), 'Nova arte'),
      }),
      React.createElement('div', { style: vw.artGrid },
        window.ARTWORKS ? window.ARTWORKS.slice(0, 8).map((a, i) => React.createElement(AdminArt, { key: a.id, art: a, status: statusOf(i) }))
          : mockArts.map((a, i) => React.createElement(AdminArt, { key: i, art: a, status: statusOf(i) }))
      )
    );
  }
  const mockArts = Array.from({ length: 8 }).map((_, i) => ({ title: 'Arte de catálogo ' + (i + 1), cat: 'sublimacao', tint: '#F2F2F2', formats: ['CDR', 'PDF'] }));

  function AdminArt({ art, status }) {
    const sStyle = status === 'Ativo' ? vw.stOn : status === 'Rascunho' ? vw.stDraft : vw.stOff;
    return React.createElement('div', { className: 'card', style: { overflow: 'hidden' } },
      React.createElement('div', { style: { position: 'relative', aspectRatio: '4 / 3', background: art.tint || 'var(--nks-gray-100)', display: 'flex', alignItems: 'center', justifyContent: 'center' } },
        React.createElement(Icon.Image, { size: 34, style: { color: 'var(--nks-gray-400)', opacity: .6 } }),
        React.createElement('span', { style: { ...vw.status, ...sStyle } }, status)
      ),
      React.createElement('div', { style: { padding: 12 } },
        React.createElement('div', { style: vw.artTitle }, art.title),
        React.createElement('div', { style: { display: 'flex', gap: 6, marginTop: 10 } },
          React.createElement('button', { className: 'btn btn-ghost btn-sm', style: { flex: 1, justifyContent: 'center' } }, React.createElement(Icon.Pencil, { size: 14 }), 'Editar'),
          React.createElement('button', { style: vw.iconBtn }, React.createElement(Icon.Trash, { size: 15 }))
        )
      )
    );
  }

  /* ---- Usuários Fase ---- */
  function Usuarios() {
    return React.createElement('div', null,
      React.createElement(window.Topbar, {
        title: 'Usuários Fase',
        desc: 'Contas da equipe interna com permissão de download.',
        action: React.createElement('button', { className: 'btn btn-dark btn-sm' }, React.createElement(Icon.Plus, { size: 16 }), 'Criar conta'),
      }),
      React.createElement('div', { className: 'card' },
        React.createElement('table', { style: vw.table },
          React.createElement('thead', null, React.createElement('tr', null,
            ['Usuário', 'Acesso', 'Último acesso', 'Downloads', ''].map((h, i) =>
              React.createElement('th', { key: i, style: { ...vw.th, textAlign: i >= 3 ? 'right' : 'left' } }, h)))),
          React.createElement('tbody', null,
            window.ADMIN_USERS.map((u, i) => React.createElement('tr', { key: i, style: vw.tr },
              React.createElement('td', { style: vw.td },
                React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 11 } },
                  React.createElement('span', { style: vw.av }, u.name[0]),
                  React.createElement('div', null,
                    React.createElement('div', { style: { fontWeight: 500, color: 'var(--nks-black)' } }, u.name),
                    React.createElement('div', { style: { fontSize: 12, color: 'var(--nks-gray-400)', fontFamily: 'var(--font-mono)' } }, u.email)
                  ))),
              React.createElement('td', { style: vw.td }, React.createElement('span', { className: 'badge badge-fase' }, 'Fase')),
              React.createElement('td', { style: { ...vw.td, color: 'var(--nks-gray-400)' } }, u.last),
              React.createElement('td', { style: { ...vw.td, textAlign: 'right', fontFamily: 'var(--font-mono)' } }, u.downloads),
              React.createElement('td', { style: { ...vw.td, textAlign: 'right' } },
                React.createElement('button', { style: vw.iconBtnSm }, React.createElement(Icon.Pencil, { size: 15 })))
            )))
        )
      )
    );
  }

  /* ---- Log de downloads ---- */
  function Log() {
    return React.createElement('div', null,
      React.createElement(window.Topbar, { title: 'Log de downloads', desc: 'Quem baixou o quê, e quando.' }),
      React.createElement('div', { className: 'card' },
        React.createElement('table', { style: vw.table },
          React.createElement('thead', null, React.createElement('tr', null,
            ['Usuário', 'Arte', 'Formato', 'Quando'].map((h, i) =>
              React.createElement('th', { key: i, style: { ...vw.th, textAlign: i === 2 ? 'center' : 'left' } }, h)))),
          React.createElement('tbody', null,
            window.ADMIN_DOWNLOADS.map((d, i) => React.createElement('tr', { key: i, style: vw.tr },
              React.createElement('td', { style: vw.td },
                React.createElement('div', { style: { fontWeight: 500, color: 'var(--nks-black)' } }, d.user),
                React.createElement('div', { style: { fontSize: 12, color: 'var(--nks-gray-400)', fontFamily: 'var(--font-mono)' } }, d.email)),
              React.createElement('td', { style: { ...vw.td, color: 'var(--nks-gray-700)' } }, d.art),
              React.createElement('td', { style: { ...vw.td, textAlign: 'center' } }, React.createElement('span', { className: 'fmt fmt-' + d.fmt }, d.fmt)),
              React.createElement('td', { style: { ...vw.td, color: 'var(--nks-gray-400)' } }, d.when)
            )))
        )
      )
    );
  }

  const vw = {
    artGrid: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 18 },
    status: { position: 'absolute', top: 10, left: 10, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.06em', padding: '3px 8px', borderRadius: 'var(--radius-sm)' },
    stOn: { background: '#fff', color: 'var(--fmt-cdr-fg)', border: '1px solid var(--fmt-cdr-bd)' },
    stDraft: { background: '#fff', color: 'var(--nks-gray-700)', border: '1px solid var(--nks-gray-200)' },
    stOff: { background: '#fff', color: 'var(--nks-gray-400)', border: '1px solid var(--nks-gray-200)' },
    artTitle: { fontSize: 13.5, fontWeight: 600, color: 'var(--nks-black)', lineHeight: 1.3 },
    iconBtn: { width: 34, height: 34, borderRadius: 'var(--radius)', border: '1px solid var(--nks-gray-200)', background: '#fff', color: 'var(--nks-gray-400)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
    iconBtnSm: { width: 30, height: 30, borderRadius: 'var(--radius)', border: '1px solid var(--nks-gray-200)', background: '#fff', color: 'var(--nks-gray-700)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
    table: { width: '100%', borderCollapse: 'collapse' },
    th: { fontSize: 11, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--nks-gray-400)', padding: '12px 18px', borderBottom: '1px solid var(--nks-gray-200)' },
    tr: { borderBottom: '1px solid var(--nks-gray-100)' },
    td: { padding: '13px 18px', fontSize: 14, verticalAlign: 'middle' },
    av: { width: 32, height: 32, borderRadius: 'var(--radius-full)', background: 'var(--nks-black)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: 13, flex: 'none' },
  };

  window.AdminArtes = Artes;
  window.AdminUsuarios = Usuarios;
  window.AdminLog = Log;
})();
