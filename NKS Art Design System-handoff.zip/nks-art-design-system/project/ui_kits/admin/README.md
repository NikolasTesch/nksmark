# UI Kit — Admin (painel `/admin`)

Recriação de alta fidelidade do painel administrativo, com foco na página exclusiva de
**Gestão de Conteúdo** (`/admin/conteudo`) e suas três abas.

## Como rodar
Abra `index.html`. A navegação lateral troca entre as telas; **Conteúdo** é a tela inicial.

## Telas (sidebar)
- **Artes** — grid de gestão com status (Ativo / Rascunho / Inativo) e ações editar/remover.
- **Upload** — drop de arquivos (CDR/AI/PDF/OTF) + metadados (título, categoria, tags,
  status, grátis).
- **Conteúdo** ⭐ — três abas:
  - **Categorias:** tabela com cor, slug e contagem; criar/editar; remoção bloqueada quando
    há artes vinculadas.
  - **Tags:** nuvem de chips com contagem de uso; criar/renomear/remover (desvincula).
  - **Filtros:** define e **reordena (drag handle)** os filtros da `/loja`; toggle
    ativar/desativar sem apagar a categoria.
- **Usuários Fase** — contas da equipe interna, criadas manualmente pelo admin.
- **Log de downloads** — quem baixou o quê, formato e quando.

## Componentes (`*.jsx`)
| Arquivo | Componente |
|---|---|
| `Sidebar.jsx` | `Sidebar` (nav preta + conta) e `Topbar` (título display + descrição + ação) |
| `Conteudo.jsx` | Abas Categorias / Tags / Filtros + `Toggle` |
| `Upload.jsx` | Formulário de upload com dropzone e metadados |
| `Views.jsx` | `AdminArtes`, `AdminUsuarios`, `AdminLog` |
| `app.jsx` | Shell que liga sidebar + view ativa |
| `data.jsx` | Categorias, tags, usuários e log mock |

## Notas
- Reaproveita `../loja/data.jsx` para o grid de artes.
- Drag-and-drop dos filtros é representado pelo *handle* (visual); a reordenação real fica a
  cargo da implementação de produção.
- Ícones via `../Icons.jsx` (Lucide). Estilos via `../../colors_and_type.css` + `../kit.css`.
