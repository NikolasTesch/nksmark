/* NKS Art — Admin sidebar + topbar shell */
(function () {
  const { Icon } = window;

  function Sidebar({ view, setView }) {
    const nav = [
      { id: 'artes', label: 'Artes', icon: Icon.LayoutGrid },
      { id: 'upload', label: 'Upload', icon: Icon.Upload },
      { id: 'conteudo', label: 'Conteúdo', icon: Icon.SlidersHorizontal },
      { id: 'usuarios', label: 'Usuários Fase', icon: Icon.Users },
      { id: 'log', label: 'Log de downloads', icon: Icon.History },
    ];
    return React.createElement('aside', { style: sb.aside },
      React.createElement('div', { style: sb.brand },
        React.createElement('img', { src: '../../assets/nks-logo-mark-white.png', alt: 'NKS', style: sb.logo }),
        React.createElement('span', { style: sb.brandTag }, 'Admin')
      ),
      React.createElement('nav', { style: sb.nav },
        nav.map(n => {
          const on = view === n.id;
          return React.createElement('button', {
            key: n.id, onClick: () => setView(n.id),
            style: { ...sb.item, ...(on ? sb.itemOn : {}) },
          },
            React.createElement(n.icon, { size: 18 }),
            React.createElement('span', null, n.label)
          );
        })
      ),
      React.createElement('div', { style: sb.foot },
        React.createElement('div', { style: sb.avatar }, 'A'),
        React.createElement('div', { style: { flex: 1, minWidth: 0 } },
          React.createElement('div', { style: sb.footName }, 'Admin NKS'),
          React.createElement('div', { style: sb.footMail }, 'admin@nksart.com.br')
        ),
        React.createElement(Icon.LogOut, { size: 16, style: { color: 'rgba(255,255,255,.5)' } })
      )
    );
  }

  function Topbar({ title, desc, action }) {
    return React.createElement('header', { style: tb.bar },
      React.createElement('div', { style: { flex: 1, minWidth: 0 } },
        React.createElement('h1', { style: tb.title }, title),
        desc && React.createElement('p', { style: tb.desc }, desc)
      ),
      action || null
    );
  }

  const sb = {
    aside: { width: 248, background: 'var(--nks-black)', minHeight: '100vh', display: 'flex', flexDirection: 'column', position: 'sticky', top: 0, flex: 'none' },
    brand: { display: 'flex', alignItems: 'center', gap: 10, padding: '22px 22px 18px' },
    logo: { height: 26 },
    brandTag: { color: 'rgba(255,255,255,.5)', fontSize: 11, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '.14em', borderLeft: '1px solid rgba(255,255,255,.2)', paddingLeft: 10 },
    nav: { display: 'flex', flexDirection: 'column', gap: 2, padding: '8px 12px', flex: 1 },
    item: { display: 'flex', alignItems: 'center', gap: 11, padding: '10px 12px', borderRadius: 'var(--radius)', border: 'none', background: 'transparent', color: 'rgba(255,255,255,.62)', fontSize: 14, fontWeight: 500, textAlign: 'left', cursor: 'pointer', width: '100%' },
    itemOn: { background: 'var(--nks-red)', color: '#fff' },
    foot: { display: 'flex', alignItems: 'center', gap: 10, padding: 16, borderTop: '1px solid rgba(255,255,255,.1)' },
    avatar: { width: 32, height: 32, borderRadius: 'var(--radius-full)', background: 'var(--nks-red)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: 14, flex: 'none' },
    footName: { color: '#fff', fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
    footMail: { color: 'rgba(255,255,255,.45)', fontSize: 11, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
  };
  const tb = {
    bar: { display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 20, marginBottom: 26 },
    title: { fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 28, letterSpacing: '-.02em', textTransform: 'uppercase', margin: 0, color: 'var(--nks-black)' },
    desc: { fontSize: 14, color: 'var(--nks-gray-400)', margin: '6px 0 0' },
  };

  window.Sidebar = Sidebar;
  window.Topbar = Topbar;
})();
