/* NKS Art — Admin > Gestão de Conteúdo (Categorias / Tags / Filtros) */
(function () {
  const { Icon } = window;
  const { useState } = React;

  function Tabs({ tab, setTab }) {
    const tabs = [
      { id: 'categorias', label: 'Categorias' },
      { id: 'tags', label: 'Tags' },
      { id: 'filtros', label: 'Filtros' },
    ];
    return React.createElement('div', { style: ct.tabs },
      tabs.map(t => React.createElement('button', {
        key: t.id, onClick: () => setTab(t.id),
        style: { ...ct.tab, ...(tab === t.id ? ct.tabOn : {}) },
      }, t.label))
    );
  }

  /* ---------- Categorias ---------- */
  function Categorias() {
    const [cats, setCats] = useState(window.ADMIN_CATEGORIES);
    return React.createElement('div', null,
      React.createElement('div', { style: ct.head },
        React.createElement('div', { style: ct.count }, cats.length + ' categorias'),
        React.createElement('button', { className: 'btn btn-dark btn-sm' },
          React.createElement(Icon.Plus, { size: 16 }), 'Nova categoria')
      ),
      React.createElement('div', { className: 'card' },
        React.createElement('table', { style: ct.table },
          React.createElement('thead', null, React.createElement('tr', null,
            ['Categoria', 'Slug', 'Artes', ''].map((h, i) =>
              React.createElement('th', { key: i, style: { ...ct.th, textAlign: i === 2 ? 'right' : 'left' } }, h))
          )),
          React.createElement('tbody', null,
            cats.map(c => React.createElement('tr', { key: c.id, style: ct.tr },
              React.createElement('td', { style: ct.td },
                React.createElement('span', { style: { ...ct.dot, background: c.color } }),
                React.createElement('span', { style: ct.catName }, c.name)
              ),
              React.createElement('td', { style: ct.td }, React.createElement('code', { style: ct.slug }, '/' + c.slug)),
              React.createElement('td', { style: { ...ct.td, textAlign: 'right' } },
                React.createElement('span', { style: ct.countPill }, c.count)
              ),
              React.createElement('td', { style: { ...ct.td, textAlign: 'right' } },
                React.createElement('div', { style: ct.rowActions },
                  React.createElement('button', { style: ct.iconBtn, title: 'Editar' }, React.createElement(Icon.Pencil, { size: 15 })),
                  React.createElement('button', {
                    style: { ...ct.iconBtn, ...(c.count > 0 ? ct.iconBtnDisabled : {}) },
                    title: c.count > 0 ? c.count + ' artes vinculadas — não é possível remover' : 'Arquivar',
                  }, React.createElement(Icon.Trash, { size: 15 }))
                )
              )
            ))
          )
        )
      ),
      React.createElement('p', { style: ct.note }, 'Categorias com artes vinculadas não podem ser removidas — arquive-as ou mova as artes antes.')
    );
  }

  /* ---------- Tags ---------- */
  function Tags() {
    const tags = window.ADMIN_TAGS;
    return React.createElement('div', null,
      React.createElement('div', { style: ct.head },
        React.createElement('div', { style: ct.count }, tags.length + ' tags'),
        React.createElement('div', { style: { display: 'flex', gap: 10 } },
          React.createElement('div', { style: { position: 'relative' } },
            React.createElement(Icon.Search, { size: 15, style: ct.searchIcon }),
            React.createElement('input', { className: 'input', style: { paddingLeft: 34, width: 200 }, placeholder: 'Buscar tag…' })
          ),
          React.createElement('button', { className: 'btn btn-dark btn-sm' },
            React.createElement(Icon.Plus, { size: 16 }), 'Nova tag')
        )
      ),
      React.createElement('div', { style: ct.tagCloud },
        tags.map(t => React.createElement('div', { key: t.id, style: ct.tagChip },
          React.createElement(Icon.Tag, { size: 13, style: { color: 'var(--nks-gray-400)' } }),
          React.createElement('span', { style: ct.tagName }, t.name),
          React.createElement('span', { style: ct.tagCount }, t.count),
          React.createElement('button', { style: ct.tagX, title: 'Remover (desvincula das artes)' }, React.createElement(Icon.X, { size: 13 }))
        ))
      ),
      React.createElement('p', { style: ct.note }, 'Remover uma tag a desvincula automaticamente de todas as artes. A ação não exclui artes.')
    );
  }

  /* ---------- Filtros ---------- */
  function Filtros() {
    const [rows, setRows] = useState(window.ADMIN_CATEGORIES.filter(c => c.slug !== 'rascunhos'));
    const toggle = id => setRows(r => r.map(x => x.id === id ? { ...x, filterOn: !x.filterOn } : x));
    return React.createElement('div', null,
      React.createElement('div', { style: ct.head },
        React.createElement('div', { style: ct.count }, 'Menu de filtros da /loja'),
        React.createElement('span', { style: ct.hint }, 'Arraste para reordenar')
      ),
      React.createElement('div', { className: 'card', style: { padding: 8 } },
        rows.map(c => React.createElement('div', { key: c.id, style: ct.filterRow },
          React.createElement('button', { style: ct.grip, title: 'Arrastar' }, React.createElement(Icon.GripVertical, { size: 16 })),
          React.createElement('span', { style: { ...ct.dot, background: c.color } }),
          React.createElement('span', { style: ct.filterName }, c.name),
          React.createElement('span', { style: ct.filterMeta }, c.count + ' artes'),
          React.createElement(Toggle, { on: c.filterOn, onClick: () => toggle(c.id) })
        ))
      ),
      React.createElement('p', { style: ct.note }, 'Desativar um filtro o oculta do menu da loja sem apagar a categoria nem suas artes.')
    );
  }

  function Toggle({ on, onClick }) {
    return React.createElement('button', {
      onClick, style: { ...ct.toggle, background: on ? 'var(--nks-red)' : 'var(--nks-gray-200)' },
    }, React.createElement('span', { style: { ...ct.knob, transform: on ? 'translateX(18px)' : 'translateX(0)' } }));
  }

  function Conteudo() {
    const [tab, setTab] = useState('categorias');
    return React.createElement('div', null,
      React.createElement(window.Topbar, {
        title: 'Gestão de conteúdo',
        desc: 'Organize categorias, tags e os filtros exibidos na loja.',
      }),
      React.createElement(Tabs, { tab, setTab }),
      tab === 'categorias' && React.createElement(Categorias),
      tab === 'tags' && React.createElement(Tags),
      tab === 'filtros' && React.createElement(Filtros)
    );
  }

  const ct = {
    tabs: { display: 'flex', gap: 4, borderBottom: '1px solid var(--nks-gray-200)', marginBottom: 24 },
    tab: { border: 'none', background: 'none', padding: '11px 16px', fontSize: 14, fontWeight: 500, color: 'var(--nks-gray-400)', cursor: 'pointer', borderBottom: '2px solid transparent', marginBottom: -1 },
    tabOn: { color: 'var(--nks-black)', borderBottomColor: 'var(--nks-red)' },
    head: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
    count: { fontSize: 13, fontWeight: 600, color: 'var(--nks-black)' },
    hint: { fontSize: 12, color: 'var(--nks-gray-400)' },
    table: { width: '100%', borderCollapse: 'collapse' },
    th: { fontSize: 11, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--nks-gray-400)', padding: '12px 18px', borderBottom: '1px solid var(--nks-gray-200)' },
    tr: { borderBottom: '1px solid var(--nks-gray-100)' },
    td: { padding: '13px 18px', fontSize: 14, color: 'var(--nks-gray-700)', verticalAlign: 'middle' },
    dot: { display: 'inline-block', width: 10, height: 10, borderRadius: 'var(--radius-full)', marginRight: 10, verticalAlign: 'middle' },
    catName: { fontWeight: 500, color: 'var(--nks-black)' },
    slug: { fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--nks-gray-400)' },
    countPill: { fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--nks-gray-700)' },
    rowActions: { display: 'inline-flex', gap: 4 },
    iconBtn: { width: 30, height: 30, borderRadius: 'var(--radius)', border: '1px solid var(--nks-gray-200)', background: '#fff', color: 'var(--nks-gray-700)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
    iconBtnDisabled: { color: 'var(--nks-gray-200)', cursor: 'not-allowed' },
    note: { fontSize: 12, color: 'var(--nks-gray-400)', marginTop: 14, lineHeight: 1.5 },
    searchIcon: { position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--nks-gray-400)' },
    tagCloud: { display: 'flex', flexWrap: 'wrap', gap: 9 },
    tagChip: { display: 'inline-flex', alignItems: 'center', gap: 7, padding: '7px 8px 7px 12px', border: '1px solid var(--nks-gray-200)', borderRadius: 'var(--radius-full)', background: '#fff' },
    tagName: { fontSize: 13, fontWeight: 500, color: 'var(--nks-black)' },
    tagCount: { fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--nks-gray-400)', background: 'var(--nks-gray-100)', borderRadius: 'var(--radius-full)', padding: '1px 7px' },
    tagX: { width: 22, height: 22, borderRadius: 'var(--radius-full)', border: 'none', background: 'transparent', color: 'var(--nks-gray-400)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
    filterRow: { display: 'flex', alignItems: 'center', gap: 12, padding: '12px 12px', borderRadius: 'var(--radius)' },
    grip: { border: 'none', background: 'transparent', color: 'var(--nks-gray-400)', cursor: 'grab', display: 'flex', padding: 0 },
    filterName: { fontSize: 14, fontWeight: 500, color: 'var(--nks-black)', flex: 1 },
    filterMeta: { fontSize: 12, color: 'var(--nks-gray-400)', fontFamily: 'var(--font-mono)' },
    toggle: { width: 38, height: 20, borderRadius: 'var(--radius-full)', border: 'none', position: 'relative', cursor: 'pointer', padding: 0, transition: 'background var(--dur) var(--ease)' },
    knob: { position: 'absolute', top: 2, left: 2, width: 16, height: 16, borderRadius: 'var(--radius-full)', background: '#fff', transition: 'transform var(--dur) var(--ease)' },
  };

  window.Conteudo = Conteudo;
})();
