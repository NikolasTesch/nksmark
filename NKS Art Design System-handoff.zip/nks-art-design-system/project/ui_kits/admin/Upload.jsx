/* NKS Art — Admin > Upload de arte */
(function () {
  const { Icon } = window;

  function Upload() {
    return React.createElement('div', null,
      React.createElement(window.Topbar, { title: 'Nova arte', desc: 'Envie os arquivos e preencha os metadados de catálogo.' }),
      React.createElement('div', { style: up.grid },
        React.createElement('div', { className: 'card', style: up.left },
          React.createElement('div', { style: up.drop },
            React.createElement(Icon.Upload, { size: 30, style: { color: 'var(--nks-gray-400)' } }),
            React.createElement('div', { style: up.dropTitle }, 'Arraste os arquivos aqui'),
            React.createElement('div', { style: up.dropSub }, 'CDR · AI · PDF · OTF — até 50 MB cada'),
            React.createElement('button', { className: 'btn btn-ghost btn-sm', style: { marginTop: 12 } }, 'Selecionar arquivos')
          ),
          React.createElement('div', { style: up.fileList },
            [['CDR', 'mandala-floral.cdr', '4,2 MB'], ['AI', 'mandala-floral.ai', '6,8 MB'], ['PDF', 'mandala-floral.pdf', '1,1 MB']].map(([f, n, s]) =>
              React.createElement('div', { key: n, style: up.fileRow },
                React.createElement('span', { className: 'fmt fmt-' + f }, f),
                React.createElement('span', { style: up.fileName }, n),
                React.createElement('span', { style: up.fileSize }, s),
                React.createElement(Icon.Check, { size: 16, style: { color: 'var(--fmt-cdr-fg)' } })
              )
            )
          )
        ),
        React.createElement('div', { className: 'card', style: up.right },
          React.createElement(Field, { label: 'Título da arte' }, React.createElement('input', { className: 'input', defaultValue: 'Mandala floral aquarela' })),
          React.createElement(Field, { label: 'Categoria' },
            React.createElement('select', { className: 'input' },
              window.ADMIN_CATEGORIES.map(c => React.createElement('option', { key: c.id }, c.name)))
          ),
          React.createElement(Field, { label: 'Tags' },
            React.createElement('div', { style: up.tagRow },
              ['floral', 'aquarela'].map(t => React.createElement('span', { key: t, className: 'badge badge-tag' }, t)),
              React.createElement('input', { className: 'input', style: { flex: 1, minWidth: 120 }, placeholder: '+ adicionar tag' })
            )
          ),
          React.createElement(Field, { label: 'Status' },
            React.createElement('div', { style: up.statusRow },
              [['Ativo', true], ['Rascunho', false], ['Inativo', false]].map(([s, on]) =>
                React.createElement('button', { key: s, style: { ...up.statusBtn, ...(on ? up.statusOn : {}) } }, s))
            )
          ),
          React.createElement('label', { className: 'field-label' }, 'Marcar como grátis (visível, baixável por visitantes)'),
          React.createElement('div', { style: { display: 'flex', gap: 10, marginTop: 18 } },
            React.createElement('button', { className: 'btn btn-primary' }, React.createElement(Icon.Upload, { size: 16 }), 'Publicar arte'),
            React.createElement('button', { className: 'btn btn-ghost' }, 'Salvar rascunho')
          )
        )
      )
    );
  }

  function Field({ label, children }) {
    return React.createElement('div', { style: { marginBottom: 18 } },
      React.createElement('label', { className: 'field-label' }, label), children);
  }

  const up = {
    grid: { display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 22, alignItems: 'start' },
    left: { padding: 18 },
    drop: { border: '1.5px dashed var(--nks-gray-200)', borderRadius: 'var(--radius)', padding: '34px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', background: 'var(--nks-gray-100)' },
    dropTitle: { fontSize: 14, fontWeight: 600, color: 'var(--nks-black)', marginTop: 12 },
    dropSub: { fontSize: 12, color: 'var(--nks-gray-400)', marginTop: 4 },
    fileList: { marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 },
    fileRow: { display: 'flex', alignItems: 'center', gap: 10, padding: '9px 11px', border: '1px solid var(--nks-gray-200)', borderRadius: 'var(--radius)' },
    fileName: { fontSize: 13, color: 'var(--nks-black)', flex: 1, fontFamily: 'var(--font-mono)' },
    fileSize: { fontSize: 12, color: 'var(--nks-gray-400)' },
    right: { padding: 22 },
    tagRow: { display: 'flex', alignItems: 'center', gap: 7, flexWrap: 'wrap' },
    statusRow: { display: 'flex', gap: 8 },
    statusBtn: { flex: 1, padding: '9px', borderRadius: 'var(--radius)', border: '1px solid var(--nks-gray-200)', background: '#fff', fontSize: 13, fontWeight: 500, color: 'var(--nks-gray-700)', cursor: 'pointer' },
    statusOn: { background: 'var(--nks-red-subtle)', borderColor: 'var(--nks-red)', color: 'var(--nks-red-dark)' },
  };

  window.Upload = Upload;
})();
