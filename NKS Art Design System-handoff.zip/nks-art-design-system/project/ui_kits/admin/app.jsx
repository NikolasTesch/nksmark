/* NKS Art — Admin app shell */
(function () {
  const { useState } = React;

  function App() {
    const [view, setView] = useState('conteudo');
    const Body = {
      artes: window.AdminArtes,
      upload: window.Upload,
      conteudo: window.Conteudo,
      usuarios: window.AdminUsuarios,
      log: window.AdminLog,
    }[view];
    return React.createElement('div', { style: { display: 'flex', minHeight: '100vh', background: 'var(--nks-gray-100)' } },
      React.createElement(window.Sidebar, { view, setView }),
      React.createElement('main', { style: { flex: 1, minWidth: 0, padding: '32px 40px 64px', maxWidth: 1080 } },
        React.createElement(Body)
      )
    );
  }

  ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
})();
