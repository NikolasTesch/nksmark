---
name: nks-art-design
description: Use this skill to generate well-branded interfaces and assets for NKS Art — a digital catalog of sublimation artwork (catálogo de artes para sublimação) — for production or throwaway prototypes/mocks. Contains design guidelines, colors, type, fonts, the logo, and UI kit components (loja pública + painel admin) for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

Key files:
- `README.md` — brand context, roles (Visitante/Fase/Admin), content & visual foundations, iconography, index.
- `colors_and_type.css` — all design tokens (tricolor palette, type scale, radii, spacing, shadows). Link or copy this.
- `assets/` — NKS logo (full PNG, transparent mark, white mark for dark headers).
- `preview/` — design-system reference cards.
- `ui_kits/loja/` — public catalog (role-aware download behavior).
- `ui_kits/admin/` — admin panel, esp. gestão de conteúdo (categorias / tags / filtros).

Design principles to honor: tricolor (vermelho `#B31217` só para ação · preto editorial ·
branco de fundo), **bordas retas** (radius 4px / 8px em cards), serifa display (DM Serif
Display) só em títulos grandes + sans funcional (DM Sans) + mono (IBM Plex Mono) só para
formatos de arquivo. O conteúdo (as artes) é o protagonista; a marca emoldura. Português do
Brasil, tom direto, sentence case, emoji só o cadeado 🔒.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets out and
create static HTML files for the user to view. If working on production code, copy assets and
read the rules here to design as an expert in this brand.

If the user invokes this skill without other guidance, ask what they want to build, ask a few
questions, and act as an expert designer outputting HTML artifacts _or_ production code.
