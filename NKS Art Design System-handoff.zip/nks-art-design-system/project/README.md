# NKS Art — Design System

**Catálogo digital de artes para sublimação e afins.** Área pública para navegação;
downloads liberados apenas para usuários autenticados da equipe interna; administração
protegida para upload, edição e gestão de conteúdo.

A identidade é **editorial e gráfica**: paleta tricolor (vermelho, preto, branco),
contraste entre uma display **quadrada e geométrica** (que ecoa o lettering anguloso da
logo) e uma sans-serif funcional, e **bordas
retas** (radius 4px) que reforçam o caráter de catálogo profissional. O conteúdo — as
artes — é sempre o protagonista; a marca emoldura, nunca compete.

> **Sobre as fontes deste sistema:** o sistema foi construído a partir da definição de
> marca fornecida pelo cliente (tokens de cor, escala tipográfica, especificação de
> componentes em Tailwind/React) e da logomarca em PNG. **Não havia codebase nem Figma
> anexados** — as recriações de UI nas pastas `ui_kits/` são reconstruções fiéis à
> especificação, não importações de produção. Se existir um repositório ou arquivo Figma,
> compartilhe para que as telas sejam alinhadas pixel a pixel.

---

## Perfis de usuário (Roles)

| Role | Acesso | Pode baixar? |
|---|---|---|
| **Visitante** | Público, sem login. Navega o catálogo, filtra por categoria/tag, vê preview. Acessa FAQ, Suporte, Sugerir Arte, Quem Somos. | ❌ Vê "Faça login para baixar" |
| **Fase** (equipe interna) | Tudo do visitante + visualiza/baixa todos os arquivos (CDR, AI, PDF, OTF). Tem "Meus Downloads". Conta criada manualmente pelo admin. | ✅ Todos os formatos |
| **Admin** (único) | Login email+senha (NextAuth). Painel `/admin`: upload com metadados, edição/remoção de artes (ativo/inativo/rascunho), gestão de contas fase, log de downloads, e gestão de conteúdo. | ✅ + gestão total |

### Página Admin — Gestão de Conteúdo (`/admin/conteudo`)
Três abas: **Categorias** (CRUD + contagem, bloqueia remoção se houver artes vinculadas),
**Tags** (CRUD + contagem de uso, remoção desvincula automaticamente), **Filtros**
(define quais categorias aparecem no menu da `/loja`, drag-and-drop para ordenar,
ativar/desativar sem apagar).

---

## CONTENT FUNDAMENTALS

Idioma: **Português do Brasil**, integralmente. Tom **direto, prático e enxuto** — fala de
equipe para equipe, sem floreio de marketing.

- **Pessoa:** trata o usuário por **"você"** implícito; verbos no imperativo curto nos CTAs
  ("Baixar arte", "Ver coleção", "Upload", "Faça login para baixar"). A marca não fala na
  primeira pessoa ("nós") exceto na página institucional **"Quem Somos"**.
- **Casing:** títulos e botões em **sentence case** ("Baixar arte", não "Baixar Arte").
  Maiúsculas reservadas para **labels de categoria/tag** e **badges** (uppercase com
  `letter-spacing` largo: `SUBLIMAÇÃO`, `FLORAL`, `GRÁTIS`, `FASE`).
- **Formatos de arquivo** sempre em caixa-alta e fonte mono: `CDR`, `AI`, `PDF`, `OTF`.
- **Microcópia funcional:** descreve estado e ação, não vende. Ex.: "🔒 Faça login para
  baixar", "Arquivado — não aparece na loja", "3 artes vinculadas — não é possível remover".
- **Emoji:** uso **mínimo e funcional**, apenas o cadeado 🔒 para indicar conteúdo bloqueado
  a visitantes. Nada decorativo.
- **Números/metadados:** discretos, em caption cinza ("Adicionada 12 mai · 4 formatos ·
  320 downloads"). Sem inflar com estatísticas desnecessárias.
- **Vibe:** ateliê gráfico organizado. Confiável, limpo, "para quem trabalha com isso o dia
  todo". Densidade de informação moderada; respiro generoso ao redor das artes.

**Exemplos de copy:**
> Hero: *"Artes prontas para sublimação"* / sub: *"Catálogo curado de estampas, frases e
> elementos vetoriais. Baixe em CDR, AI, PDF e OTF."*
> Estado bloqueado: *"🔒 Faça login para baixar"*
> Vazio: *"Nenhuma arte nesta categoria ainda."*

---

## VISUAL FOUNDATIONS

**Cor.** Paleta tricolor estrita. **Branco** é o fundo padrão — deixa as artes brilharem.
**Preto** (`#111`) carrega peso editorial: header, badges de categoria, botões de admin.
**Vermelho** (`#B31217`) é **exclusivo de ação** — CTAs, links ativos, destaques pontuais.
*Nunca* usar vermelho como fundo de seções inteiras. Cinzas estruturam (bordas `#DEDEDE`,
fundos de card/input `#F2F2F2`, texto secundário `#888`). Cores de formato (verde/laranja/
vermelho/azul suaves) aparecem **apenas** nos badges CDR/AI/PDF/OTF.

**Tipografia.** *Archivo* (700/800) — grotesca **quadrada e geométrica**, em caixa-alta com
tracking negativo, ecoando o lettering anguloso da logo — só em títulos grandes (hero,
seções); nunca em texto corrido. *DM Sans* (400/500/600) faz todo o trabalho funcional.
*IBM Plex Mono* (400/500) é restrita a formatos de arquivo e snippets técnicos. O contraste
entre a display geométrica e a sans neutra é o motivo tipográfico central.

**Espaçamento.** Base 4px. Cards de arte com padding 12–16px; seções com respiro de
48–64px. Densidade moderada, nunca apertada.

**Backgrounds.** Sem gradientes decorativos, sem texturas, sem padrões. Fundo branco liso
ou preto sólido. As imagens das artes (previews 4:3) são a única fonte de cor "rica" — sua
temperatura varia (é catálogo de estampas), então a moldura permanece neutra de propósito.

**Bordas & radius.** **Bordas retas** são identidade: `4px` no padrão, `8px` em cards de
arte. Cantos `full` (pílula) apenas em chips de filtro e avatares. Bordas finas de `1px`
em `#DEDEDE`; nada de bordas grossas coloridas. Evitar o clichê "card arredondado com
borda esquerda colorida".

**Sombras/elevação.** Discretas e neutras (`rgba(17,17,17,.06–.14)`). Cards no estado base
usam borda + sombra muito sutil; hover eleva 1 nível. Sem glow, sem sombra colorida.

**Hover/press.** Botões: hover **escurece** (`red → red-dark`; `black → gray-900`); ghost
e outline ganham fundo suave (`gray-100` / `red-subtle`). Cards de arte: leve elevação de
sombra + zoom sutil (~1.03) na imagem de preview. Press: escurece mais um passo, sem
encolher demais. Transições rápidas (160ms, ease suave). Sem bounce.

**Transparência/blur.** Uso pontual: overlay do cadeado em previews bloqueados
(`rgba(0,0,0,.6)`), header pode ter leve `backdrop-blur` ao fixar no topo. Nada de
glassmorphism difundido.

**Imagery.** Previews de arte em proporção **4:3**, `object-cover`, fundo `gray-100`
enquanto carrega. Temperatura variável (depende da estampa). Logo nunca sobre imagem
movimentada — sempre sobre preto ou branco.

---

## ICONOGRAPHY

- **Sistema:** [**Lucide**](https://lucide.dev) (stroke ~1.75px, cantos levemente
  arredondados nas pontas) — escolhido por combinar com a sans funcional e as bordas retas
  sem brigar. Carregado via CDN (`lucide@latest`) nos kits. *Substituição sinalizada:* a
  especificação original não nomeava um icon set; Lucide é a escolha recomendada — confirme
  ou indique outro.
- **Tamanhos:** 16px (inline/caption), 18–20px (botões, nav), 24px (vazios/destaque).
  Cor `currentColor`, herdando do texto (cinza-700 padrão, vermelho quando ativo, branco
  sobre header preto).
- **Emoji:** somente 🔒 (cadeado), funcional, para conteúdo bloqueado a visitantes.
- **Logomarca:** wordmark "NKS" em vermelho com pequeno ramo de frutos (sprig) abaixo —
  toque artesanal/botânico que humaniza o conjunto gráfico. Variantes em `assets/`.
- **Badges de formato** não são ícones — são chips **monocromáticos** em fonte mono pequena
  (`CDR`/`AI`/`PDF`/`OTF`), texto preto sobre branco com borda fina; mantêm o foco na arte.

---

## Index — arquivos deste sistema

| Arquivo / pasta | Conteúdo |
|---|---|
| `README.md` | Este documento — contexto, fundamentos de conteúdo e visuais, iconografia. |
| `colors_and_type.css` | Tokens CSS: cores (base + semânticas), tipografia, escala, radii, espaçamento, sombras, motion. |
| `SKILL.md` | Manifesto para uso como Agent Skill. |
| `assets/` | Logomarca (full PNG, mark transparente, mark branco). |
| `preview/` | Cards do Design System (cores, tipografia, espaçamento, componentes, marca). |
| `ui_kits/loja/` | UI kit da **loja pública** — catálogo, filtros, card de arte, página de arte, estados por role. |
| `ui_kits/admin/` | UI kit do **painel admin** — gestão de conteúdo (abas Categorias/Tags/Filtros), upload, log de downloads. |

### Fontes (Google Fonts — via CDN, sem arquivos locais)
`Archivo` (600/700/800), `DM Sans` (400/500/600), `IBM Plex Mono` (400/500). Todas hospedadas no
Google Fonts; nenhum arquivo de fonte foi necessário copiar.
